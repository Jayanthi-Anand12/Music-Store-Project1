SELECT Round(avg(Total_Sales),2) as Avg_Sales
 FROM `numeric-ocean-436007-f4.Blinkit.Blink_data` 