SELECT total
 FROM `numeric-ocean-436007-f4.Music_Store.Invoice`
 order by total desc
  LIMIT 3